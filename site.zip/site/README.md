# CAMILLA Beauty Studio — upgraded site

The project includes a lightweight Python server and SQLite backend, so the
requested command works without installing Django:

```bash
python manage.py runserver
```

Then open http://127.0.0.1:8000/. A custom port is also supported:

```bash
python manage.py runserver 0.0.0.0:8080
```

The backend exposes `/api/auth/register`, `/api/auth/login`, `/api/auth/logout`,
`/api/auth/me`, `/api/services`, `/api/bookings` and `/api/notifications`.
SQLite data is stored in `camilla.sqlite3` and should not be committed.

## What's inside
- `index.html` — page structure (all sections preserved from the original site)
- `css/style.css` — design system + all motion (scroll reveals, pinned reel, ripples, Ken Burns, cursors, marquees…)
- `js/i18n.js` — RU / UZ / EN dictionary (language switcher in the header, saved in localStorage)
- `js/app.js` — services data, catalog, booking flow, animations
- `images/` — portfolio & gallery photos

## Owner settings (js/app.js, top of file)
```js
const CONFIG = {
  instagram: "shakhlo_nails",      // Instagram handle
  telegram: "shahloNailSTUDIO",    // Telegram username
  instagramURL: "https://www.instagram.com/shakhlo_nails",
  telegramURL: "https://t.me/shahloNailSTUDIO",
  tz: "Asia/Tashkent"
};
```
- **Prices / services / durations** — edit the `SERVICES` array in `js/app.js` (names in 3 languages).
- **Specialist photo** — replace the placeholder block in `index.html` (`#specialist` → `.spec-photo`) with an `<img>`.
- Booking flow ends with "Send via Telegram / Instagram / Copy text": the message is copied to the clipboard and the messenger opens (messengers don't allow pre-filled DMs, so the client pastes the text).

## Motion upgrades (scroll & click)
Word-mask hero reveal • staggered scroll reveals • pinned horizontal Reels strip with % counter and center-focus scaling • Ken Burns breathing on images • parallax orbs & floating hero cards • custom cursor with hover-grow • click ripples on every button/chip/tab • magnetic buttons • tilt cards • scrollspy nav + hide-on-scroll glass header • scroll progress bar • animated counters • sparkle burst on booking confirmation • shake + toast on validation errors • lightbox zoom • marquees • full `prefers-reduced-motion` fallback.
